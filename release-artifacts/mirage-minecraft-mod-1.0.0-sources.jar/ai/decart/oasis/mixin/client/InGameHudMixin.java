package ai.decart.oasis.mixin.client;

import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.Mixin;

import ai.decart.oasis.OasisClient;
import net.minecraft.class_329;
import net.minecraft.class_332;
import net.minecraft.class_9779;

@Mixin(class_329.class)
public class InGameHudMixin {
	@Inject(method = "render", at = @At("HEAD"))
	private void beforeRender(class_332 context, class_9779 tickCounter, CallbackInfo ci) {
		OasisClient.INSTANCE.beforeInGameHudRender(context);
	}
}
