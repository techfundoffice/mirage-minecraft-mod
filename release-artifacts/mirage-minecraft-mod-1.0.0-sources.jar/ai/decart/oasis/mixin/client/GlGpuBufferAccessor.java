package ai.decart.oasis.mixin.client;

import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;
import org.spongepowered.asm.mixin.gen.Invoker;

import java.nio.ByteBuffer;
import java.util.function.Supplier;
import net.minecraft.class_10859;
import net.minecraft.class_10874;

@Mixin(class_10859.class)
public interface GlGpuBufferAccessor {
	@Invoker("<init>")
	static class_10859 create(@Nullable Supplier<String> debugLabelSupplier, class_10874 bufferManager, int usage, int size, int id, @Nullable ByteBuffer backingBuffer) {
		throw new AssertionError();
	}

	@Accessor("id")
	int getId();
}
