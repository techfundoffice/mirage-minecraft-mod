package ai.decart.oasis.mixin.client;

import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.Mixin;

import ai.decart.oasis.OasisClient;
import net.minecraft.class_761;

@Mixin(class_761.class)
public class WorldRendererMixin {
	@Inject(method = "renderClouds", at = @At("HEAD"), cancellable = true)
	private void killClouds(CallbackInfo ci){
		if (!OasisClient.INSTANCE.shouldRenderClouds()) {
			ci.cancel();
		}
	}
}
